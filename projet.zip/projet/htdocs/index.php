<?php

//Smarty

require_once('/usr/local/lib/smarty/libs/Smarty.class.php');

$smarty = new Smarty();

$smarty->template_dir = '/var/www/projet/templates/'; 
$smarty->compile_dir = '/var/www/projet/template_c/';
$smarty->config_dir = '/var/www/projet/configs/';
$smarty->cache_dir = '/var/www/projet/cache/';

$smarty->assign('name','Ned');

$smarty->display('index.tpl');







?>
