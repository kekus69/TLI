<?php
/* Smarty version 3.1.28, created on 2016-03-20 22:50:49
  from "/var/www/html/projet/templates/index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.28',
  'unifunc' => 'content_56ef1b39630524_93966120',
  'file_dependency' => 
  array (
    'd36ee7aeccc5b71b046b180a4fa451df2d0c5f29' => 
    array (
      0 => '/var/www/html/projet/templates/index.tpl',
      1 => 1458510641,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56ef1b39630524_93966120 ($_smarty_tpl) {
?>
HELLO
<?php }
}
