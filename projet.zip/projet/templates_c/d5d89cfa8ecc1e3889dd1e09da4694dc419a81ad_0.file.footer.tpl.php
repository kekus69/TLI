<?php
/* Smarty version 3.1.28, created on 2016-03-20 23:15:01
  from "/var/www/html/projet/templates/footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.28',
  'unifunc' => 'content_56ef20e5185283_81390531',
  'file_dependency' => 
  array (
    'd5d89cfa8ecc1e3889dd1e09da4694dc419a81ad' => 
    array (
      0 => '/var/www/html/projet/templates/footer.tpl',
      1 => 1458511973,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56ef20e5185283_81390531 ($_smarty_tpl) {
?>
</div> <!-- END CONTENT --> <!--FOOTER--> <div id="footer"> </div> <!--END FOOTER--> </body> </html>
<?php }
}
