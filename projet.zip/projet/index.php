<?php

//Smarty
define('SMARTY_DIR', '/var/www/html/projet/smarty/libs/');

require_once(SMARTY_DIR . 'Smarty.class.php');

$smarty = new Smarty();

$smarty->setTemplate_dir = '/var/www/html/projet/templates/'; 
$smarty->setCompile_dir = '/var/www//html/projet/template_c/';
$smarty->setConfig_dir = '/var/www/html/projet/configs/';
$smarty->setCache_dir = '/var/www/html/projet/cache/';

$smarty->assign('name','Ned');
$smarty->assign('title', 'test');

//$smarty->debugging = true;

$smarty->display('header.tpl');
$smarty->display('index.tpl');
$smarty->display('footer.tpl');






?>
